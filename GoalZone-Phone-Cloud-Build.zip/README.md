# GoalZone Android project

This is a Kotlin + Jetpack Compose Android starter project.

Important: match entries currently shown in the app are illustrative demo data, not live scores. No live match video is included. Real-time scores require a licensed football data API. Broadcast listings require verified, country-specific official broadcaster data and links.

## Build on GitHub using only a phone
1. Create a new GitHub repository named GoalZone.
2. Upload the contents of this ZIP into the repository root (not the enclosing folder).
3. Add the workflow file at `.github/workflows/android-apk.yml` (included in this ZIP).
4. Open the Actions tab, choose "Build GoalZone APK", and tap "Run workflow".
5. When the workflow finishes, open its run and download the `GoalZone-debug-apk` artifact.
6. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone.

This APK is a debug build for testing, not a signed Play Store release.
